import React, { useState } from "react";
// import {getCurrentDate} from './utils'
import { Layout, Container, Button, Col, Row ,Card, Form} from "react-bootstrap";

function AddNotif({ onAdd }) {
  const [body, setBody] = useState("");
  const [author, setAuthor] = useState("");
  const [date, setDate] = useState("");
  // const [time, setTime] = useState("");

  // Submit form
  const onSubmit = (e) => {
    e.preventDefault();

    if (!body || !author) {
      alert("Please fill all the fields");
      return;
    }

    var today = new Date(),
      date =
        today.getFullYear() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getDate() +
        " at " +
        today.getHours() +
        ":" +
        today.getMinutes();

    setDate(today);

    onAdd({ author, body, date });

    setBody("");
    setDate("");
    setAuthor("");
  };

  return (
    <Container style={styles.container}>

      <Form onSubmit={onSubmit} style ={styles.form}>
      <Form.Group>
        <Form.Label>Author</Form.Label>
      </Form.Group>
        
        <Form.Group>
        <input style = {styles.formAuthor}
          type="text"
          placeholder="Posted By"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label>Announcement</Form.Label>
        </Form.Group>
        <Form.Group>
          <input style = {styles.formAnnouncement}
            type="text"
            placeholder="Announce something to the group"
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
        </Form.Group>

        {/* <Form.Group>
          <Form.Label>Day</Form.Label>
        </Form.Group>

        <Form.Group>
          <input style = {{backgroundColor:'lightgray', width:'60%',borderRadius:'0.5rem'}}
            type="text"
            placeholder="Date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </Form.Group> */}

        {/* <Form.Group>
          <Form.Label>Time</Form.Label>
        </Form.Group>

        <Form.Group>
          <input style = {{backgroundColor:'lightgray', width:'60%', borderRadius:'0.5rem'}}
            type="text"
            placeholder="Time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
          />
        </Form.Group> */}
        <Button className='btn btn-secondary' type="submit" value="Post" >Post</Button>
      </Form>
    </Container>
  );
}

const styles={
  container:{
    border:'solid #000', borderRadius:'0.5rem', borderWidth:'0.2rem', width:'30rem',marginTop:'1rem', marginBottom:'2rem',paddingTop:'1rem', paddingBottom:'1rem'
  },
  form:{
    textAlign:'center',
  },
  formAuthor:{
    backgroundColor:'#fcfcff', height:'2.5rem', width:'70%',borderRadius:'0.5rem'
  },
  formAnnouncement:{
    backgroundColor:'#fcfcff', height:'6rem', width:'90%',borderRadius:'0.5rem'
  }
}

export default AddNotif;