import React from 'react'
import { Layout, Container, Button, Col, Row } from "react-bootstrap"; //boostrap classes
import { Link } from 'react-router-dom';
import campusImg from '../images/campus.jpg';

function Home() {
    return (
        <div>
            <Container style ={styles.container}>
                <Link style={styles.link} to="/dashboard">
                    <Button style={styles.button} variant= "secondary">Get Started</Button>
                </Link>
            </Container>
        </div>
    )
}
const styles = {
    container:{
        display: 'flex',
        width:'100%',
        height: '500px',
        marginTop: '1.5rem',
        padding: '10px',
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.7)),url(${campusImg})`,
        backgroundRepeat:'no-repeat',
        backgroundPosition:'center',
        backgroundColor:'skyblue',
        backgroundSize:'cover',
    },
    button:{
        
    },
    link:{
        marginTop:'auto',
        marginLeft:'auto',
        textDecoration:'none',
    }
}

export default Home
