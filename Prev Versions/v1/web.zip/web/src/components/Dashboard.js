import React from 'react'
import { Layout, Container, Button, Col, Row, Card } from "react-bootstrap";
import {Link} from 'react-router-dom';

function Dashboard() {
    return (
        <div>
            <Row style={styles.row}>
                <h1 style={styles.heading}>"Don't let a deadline keep you home!"</h1>
            </Row>
            <Container style={styles.container}>
                <Link to="/esya">
                    <Button variant="primary">Esya</Button>
                </Link>
                <Link to="/esya">
                    <Button variant="primary">Induction</Button>
                </Link>
                <Link to="/odyssey">
                    <Button variant="primary">Odyssey</Button>
                </Link>
            </Container>

            <Container style={styles.container2}>
                <Link>
                    <Button variant="primary">Other Events</Button>
                </Link>
                <Link>
                    <Button variant="primary">Calendar</Button>
                </Link>
            </Container>
        </div>
    )
}
const styles={
    container:{
        marginTop:'2rem',
        width:'80%',
        display:'flex',
        justifyContent:'space-between',
    },
    container2:{
        marginTop:'2rem',
        width:'50%',
        display:'flex',
        justifyContent:'space-between',
    },
    heading:{
        fontSize:'2rem',
        marginRight:'auto',
        fontStyle:'italic',
        marginLeft:'auto',
    },
    row:{
        marginTop:'1.5rem',
        
    },
    link:{
        marginLeft:'auto', 
        marginRight:'auto',
    }
}
export default Dashboard
