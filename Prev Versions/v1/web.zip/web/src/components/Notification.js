import React from "react";
import { Layout, Container, Button, Col, Row ,Card} from "react-bootstrap";
import {FaTimes, FaBullhorn} from 'react-icons/fa'

function Notification({ author, body, date}) {
  return (
    <div style={styles.container}>
        <Card style={styles.card}>
            <Card.Body>
                <Card.Title style={styles.title}> <FaBullhorn></FaBullhorn> Posted By: <span style={{fontWeight:'normal',color:'gray'}}>{author}</span></Card.Title>

                <Card.Footer style={styles.footer} >
                    <Card.Text style={styles.body}>{body}</Card.Text>
                    <p>{date}</p>
                </Card.Footer>
            </Card.Body>
        </Card>
    </div>
  );
}

const styles={
  card:{
    textAlign:'center'
  },
  container:{
    paddingBottom:'1rem', width: '100%'
  },
  title:{
    textAlign:'left',fontSize:'1.5rem'
  },
  footer:{
    textAlign:'right'
  },
  body:{
    textAlign:'left',fontSize:'1.1rem',fontWeight:'bold'
  },

}

export default Notification;