import React, { Component } from "react";
import { Container, Navbar, Button } from "react-bootstrap";

function Header() {
  return (
    <Navbar className="shadow-lg" expand="lg" variant="light" bg="dark">
      <Container>
        <Navbar.Brand style={{ color: "whitesmoke" }} href="#">
          Fest@IIITD
        </Navbar.Brand>
      </Container>
    </Navbar>
  );
}

export default Header;