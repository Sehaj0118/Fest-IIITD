import React from "react";
import { Layout, Container, Button, Col, Row } from "react-bootstrap";

function Started() {
  return (
    <div>
      <Container>
        <Row>
          <Col>
            <p style={{ marginTop: 100 }}>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s, when an unknown printer took a galley of
              type and scrambled it to make a type specimen book. It has
              survived not only five centuries, but also the leap into
              electronic typesetting, remaining essentially unchanged. It was
              popularised in the 1960s with the release of Letraset sheets
              containing Lorem Ipsum passages, and more recently with desktop
              publishing software like Aldus PageMaker including versions of
              Lorem Ipsum
            </p>
            <div className="mt-5 text-left">
              <Button
                style={{ width: 180 }}
                size="sm"
                className="pl-4 pr-4 rounded-pill"
                variant="outline-dark"
              >
                <p style={{ fontSize: 16.5, marginTop: 10 }}>
                  Tap to get started
                </p>
              </Button>
            </div>
          </Col>
          <Col>2 of 2</Col>
        </Row>
      </Container>
    </div>
  );
}

export default Started;