import React from 'react';
import {Link} from 'react-router-dom';
import { Layout, Container, Button, Col, Row, Card } from "react-bootstrap";
import Stats from './Stats';
import Image from './Image';
import myImage from '../images/esya.png';

function Esya() {

    const footfallDataPoints=[
        { y: 6000, label: "2016" },
        { y: 8500, label: "2017" },
        { y: 7200, label: "2018" },
        { y: 10000, label: "2019"},
    ]
    
    const eventDataPoints=[
        { y: 30, label: "PWNED" },
        { y: 24, label: "PUBG" },
        { y: 10, label: "Robo Wars" },
        { y: 8, label: "ProSort"},
    ]

    return (
        <div>
            <Container>
                <Image path={myImage} text = "Go to the Website" />
            </Container>
            <Stats header="Campus Footfall" type="line" dataPoints={footfallDataPoints} />
            <Stats header="Popular Events" type="column" label="Teams" dataPoints={eventDataPoints} />
     
            <Container>
                <Row style = {styles.row}>
                    <Col>
                        <Card style={styles.card}>
                            {/* <Card.Img variant="top" src= /> */}
                            <Card.Body>
                                <Card.Title>Register</Card.Title>
                                <Card.Text>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus ex animi voluptatem dolores distinctio voluptates, saepe laudantium vel fuga</p>
                                </Card.Text>
                                <Button variant="primary">Go To Registration</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col>
                    <Card style={styles.card}>
                            {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                            <Card.Body>
                                <Card.Title>Announcements</Card.Title>
                                <Card.Text>
                                    <p>
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus ex animi voluptatem dolores distinctio voluptates, saepe laudantium vel fuga    
                                    </p>
                                </Card.Text>
                                <Link to="/esya/notifications">
                                    <Button variant="primary">Go To Anouncements</Button>
                                </Link>
                                
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col>
                    <Card style={styles.card}>
                            {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                            <Card.Body>
                                <Card.Title>Frequently Asked Questions</Card.Title>
                                <Card.Text>
                                    <p>
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus ex animi voluptatem dolores distinctio voluptates, saepe laudantium vel fuga    
                                    </p>
                                </Card.Text>
                                <Button variant="primary">Go To FAQ</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}
const styles={
    card:{
        borderRadius:'1rem',
        width: '18rem'
    },
    row: {
        padding: '1.5rem 0 1.5rem 0',

    }
}
export default Esya
