import {useState} from 'react';
import { Layout, Container, Button, Col, Row } from "react-bootstrap"; //boostrap classes
import "bootstrap/dist/css/bootstrap.min.css";
import Dashboard from './components/Dashboard'
import Header from "./components/Header";
import Esya from "./components/Esya";
import Odyssey from "./components/Odyssey";
import Home from "./components/Home";
import Notifications from "./components/Notifications";
import {BrowserRouter as Router, Switch, Route} from "react-router-dom";

function App() {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      author: "Design - OT",
      body: "Design volunteers, please assemble near OAT",
      date: "2021-05-15 at 10:45"
    },
    {
      id: 2,
      author: "ECE - OC ",
      body: "We will start with our briefing in 5 mins. Please join.",
      date: "2021-05-19 at 13:20"
    },
    {
      id: 3,
      author: "OC",
      body: "Please fill the form for your OT t-shirts",
      date: "2021-05-21 at 15:30"
    },
  ]);

  // Add announcement
  const addAnnouncement = (notification) => {
    const id = notifications.length + 1;
    const newNotification = { id, ...notification };
    setNotifications([...notifications, newNotification]);
  };

  const footfallDataPoints=[
    { y: 6000, label: "2016" },
    { y: 8500, label: "2017" },
    { y: 7200, label: "2018" },
    { y: 10000, label: "2019"},
  ]

  const eventDataPoints=[
    { y: 30, label: "PWNED" },
    { y: 24, label: "PUBG" },
    { y: 10, label: "Robo Wars" },
    { y: 8, label: "2019"},
  ]
  return (
    <Router>
      
      <Header/>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/odyssey" exact component={Odyssey}/> 
        <Route path="/dashboard" exact component={Dashboard}/>
        <Route path="/esya" exact component={Esya} />
        <Route path="/odyssey/notifications" exact component={() => <Notifications notifications={notifications} 
        addNotification={addAnnouncement} />}/>
        <Route path="/esya/notifications" component={() => <Notifications notifications={notifications}
        addNotification={addAnnouncement}/>} />
      </Switch>
      
      {/* <Stats header="Campus Footfall" type="line" dataPoints={footfallDataPoints} />
      <Stats header="Popular Events" type="column" label="Teams" dataPoints={eventDataPoints} />
      */}
      {/* <Notifications 
        notifications={notifications}
        addNotification={addAnnouncement}
      /> */}

    </Router>
  );
}


export default App;